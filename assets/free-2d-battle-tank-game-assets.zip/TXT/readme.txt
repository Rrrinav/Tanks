Aldo the Apache
https://www.dafont.com/aldo-the-apache.font